

function logout() {
    localStorage.removeItem("loggedIn");
    location.reload();
}

function showApp() {
    document.getElementById("loginPage").style.display = "none";
    document.getElementById("appPage").style.display = "block";
}

// Check login on load
window.onload = function() {
    if (localStorage.getItem("loggedIn") === "true") {
        showApp();
    }
    displayCases();
};

// DARK MODE
function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
}
function submitCase() {
    const fileInput = document.getElementById("fileInput");
    const checkboxes = document.querySelectorAll("input[type='checkbox']:checked");

    if (!fileInput.files.length) {
        alert("Please upload a file.");
        return;
    }

    let riskScore = 0;

checkboxes.forEach(cb => {
    riskScore += parseInt(cb.value);
});
    let riskLevel = "";

    if (riskScore <= 2) {
        riskLevel = "Low Risk";
    } else if (riskScore <= 5) {
        riskLevel = "Medium Risk";
    } else {
        riskLevel = "High Risk";
    }

    let caseID = "DS" + Math.floor(Math.random() * 100000);
    let timestamp = new Date().toLocaleString();

    let caseData = {
        id: caseID,
        fileName: fileInput.files[0].name,
        risk: riskLevel,
        time: timestamp
    };

    let cases = JSON.parse(localStorage.getItem("cases")) || [];
    cases.push(caseData);
    localStorage.setItem("cases", JSON.stringify(cases));

   let color = "green";

if (riskLevel === "Medium Risk") color = "orange";
if (riskLevel === "High Risk") color = "red";

document.getElementById("result").innerHTML =
    `<strong>Case Submitted Successfully!</strong><br>
    Case ID: ${caseID} <br>
    Risk Level: <span style="color:${color}; font-weight:bold;">${riskLevel}</span>`;

    displayCases();
}

function displayCases() {
    let cases = JSON.parse(localStorage.getItem("cases")) || [];
    let historyDiv = document.getElementById("history");
    historyDiv.innerHTML = "<h3>Case History</h3>";

    cases.forEach(c => {
        historyDiv.innerHTML +=
            `<p><b>${c.id}</b><br>
            File: ${c.fileName}<br>
            Risk: ${c.risk}<br>
            Time: ${c.time}</p><hr>`;
    });
}
let isLogin = true;

function toggleForm() {
    const title = document.getElementById("formTitle");
    const button = document.getElementById("authButton");
    const toggleText = document.getElementById("toggleText");
    const message = document.getElementById("authMessage");

    message.innerHTML = "";

    if (isLogin) {
        title.innerText = "DeepSafe Her Sign Up";
        button.innerText = "Sign Up";
        toggleText.innerHTML = `
            Already have an account?
            <span onclick="toggleForm()" class="link-text">Login</span>
        `;
    } else {
        title.innerText = "DeepSafe Her Login";
        button.innerText = "Login";
        toggleText.innerHTML = `
            Don't have an account?
            <span onclick="toggleForm()" class="link-text">Sign Up</span>
        `;
    }

    isLogin = !isLogin;
}

function handleAuth() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const message = document.getElementById("authMessage");

    if (!username || !password) {
        message.style.color = "red";
        message.innerText = "Please fill all fields.";
        return;
    }

    if (isLogin) {
        const storedUser = localStorage.getItem(username);

        if (!storedUser) {
            message.style.color = "red";
            message.innerText = "User not found. Please sign up.";
            return;
        }

        const userData = JSON.parse(storedUser);

        if (userData.password === password) {
            message.style.color = "green";
            message.innerText = "Login successful!";
            showApp();
        } else {
            message.style.color = "red";
            message.innerText = "Incorrect password.";
        }

    } else {
        if (localStorage.getItem(username)) {
            message.style.color = "red";
            message.innerText = "Username already exists.";
            return;
        }

        const userData = {
            username: username,
            password: password
        };

        localStorage.setItem(username, JSON.stringify(userData));

        message.style.color = "green";
        message.innerText = "Sign up successful! Please login.";
        toggleForm();
    }
}

function showApp() {
    document.getElementById("loginPage").style.display = "none";
    document.getElementById("appPage").style.display = "block";
}

window.onload = displayCases;